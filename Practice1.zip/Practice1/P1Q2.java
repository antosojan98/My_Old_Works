/**
 * Auto Generated Java Class.
 */
import java.util.*;

public class P1Q2 {
  
  
  public static void main(String[] args) { 
    
    Scanner sc=new Scanner(System.in);
     
    int eggs, dozen, rest;    
  
    System.out.println("How many eggs do you have?");
    
    eggs=sc.nextInt();
    
    dozen=eggs/12;
    rest=eggs%12;
    
    System.out.println("You have "+dozen+" dozen and "+rest+" single eggs.");
    
  }
  
  /* ADD YOUR CODE HERE */
  
}
