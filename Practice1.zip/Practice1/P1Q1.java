/**
 * Auto Generated Java Class.
 */
import java.util.*;

public class P1Q1 {
  
  
  public static void main(String[] args) { 
    
    Scanner sc=new Scanner(System.in);
    
    int quarters,dimes,nickels;    
    double dollars;
        
    
    System.out.println("How many quarters do you have?");    
    quarters=sc.nextInt();
    
    System.out.println("How many dimes do you have?");    
    dimes=sc.nextInt();
    
    System.out.println("How many nickels do you have?");
    nickels=sc.nextInt();
    
    dollars=(quarters*0.25)+(dimes*0.1)+(nickels*0.05);
    
    // For some totally weird reason if you input 1 each you get a freaky long number?
    
    System.out.println("You have a total of "+dollars+" dollar(s).");
    
  }
  
  /* ADD YOUR CODE HERE */
  
}
