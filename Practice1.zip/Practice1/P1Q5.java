/**
 * Auto Generated Java Class.
 */
import java.util.*;

public class P1Q5 {
  
  
  public static void main(String[] args) { 
    
    Scanner sc=new Scanner(System.in);
    
    String input;
       
    do{
    System.out.println("Please enter a valid password.");
    input=sc.nextLine();
    if (Passwordchecker(input)==false){    
      System.out.println("Invalid password.");
    }else{
    System.out.println("Valid password.");    
    }
    }while(Passwordchecker(input)==false);
            
  }
  
  //creating my own method here cause its so much better to just do that
  
      public static boolean Passwordchecker(String s) {
        
        String temp;
        char c;
        int counter=0;
        boolean uppercase=false;
        boolean lowercase=false;
        int numbers=0;
        
        //uppercase check
        while(counter<s.length()){
          
          temp=s.substring(counter, (counter+1));
          
          if(temp.equals(temp.toUpperCase() )){
            uppercase=true;
          }
         counter++;
       
        }
        
        counter=0;
        
        //lowercase check
        while(counter<s.length()){
          
         temp=s.substring(counter, (counter+1));
          
          if(temp.equals(temp.toLowerCase() )){
            lowercase=true;
          }
          counter++;
       
       }
        
       counter=0;
        
       //numbercounter
       while(counter<s.length()){
          
         c=s.charAt(counter);
         if(c >='0' && c <='9'){
         numbers++;
         }
         counter++;
       
       }          
        
       //check if all conditions are met
        if(s.length()<8 || uppercase==false || lowercase == false || numbers <3){
          return false;  
        }else{
        return true;
        }
      }
  

  
}
