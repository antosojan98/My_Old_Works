/**
 * Auto Generated Java Class.
 */
import java.util.*;

public class P1Q4 {
  
  
  public static void main(String[] args) { 
    
    Scanner sc=new Scanner(System.in);
    
    String input;
    int counter=0;
    int spacecounter=0;
    
    System.out.println("Please enter your favorite movie quote.");
    input=sc.nextLine();
    
    // Just recycled Question 3 below
    
    while(counter<input.length()){
    
      if (input.charAt(counter)==' '){
        
        spacecounter++;     
        input=input.substring(counter+1);
                  
        counter=0;
      }
      counter++;    
    }    
     System.out.println("Your quote contains "+spacecounter+" space(s).");    
  }
  
  /* ADD YOUR CODE HERE */
  
}
