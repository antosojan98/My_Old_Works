/**
 * Auto Generated Java Class.
 */
import java.util.*;

public class P1Q6 {
  
  
  public static void main(String[] args) { 
    
    Scanner sc=new Scanner(System.in);
    
    int number,bnumber;

    System.out.println("Please enter a number.");
    number=sc.nextInt();
    
    while(number>0){
    
    bnumber=number%2;
    number=number/2;
    
    System.out.println(bnumber);
    
    }    
  
 
  }
  
  /* ADD YOUR CODE HERE */
  
}
